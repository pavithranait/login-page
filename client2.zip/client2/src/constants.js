export const API = "GET http://localhost/phpmyadmin/index.php?route=/sql&pos=0&db=mydb3&table=users1";
export const ActionTypes = {
    GET_DATA: "GET_DATA",
  
  }
  