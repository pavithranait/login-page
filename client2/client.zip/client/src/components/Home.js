import React from "react";
import Header from "./Header";
import { useEffect, useState } from "react";
import { API } from "../constants";
import FileUpload from "./FileUpload";

const Home = () => {
    
  return (
    <div className="homee">
      <div>
        <Header />
      </div>
    </div>
    
  );
};

export default Home;
